#include "mphyNormalEquationSolverStrategy.h"
#include <Eigen/Dense>
#include <iostream>
#include <typeinfo>
mphy::LinearSolution mphyNormalEquationSolverStrategy::FitData(mphy::LabelledData v) {
    Eigen::MatrixXd x(v.size(), 2);
    Eigen::MatrixXd y(v.size(), 1);
    for (int i = 0; i < v.size(); ++i) {
        x(i, 0) = 1;
        x(i, 1) = v[i].first;
        y(i, 0) = v[i].second;
    }

    auto t = x.transpose();
    auto p = (t * x).inverse() * t * y;
    return std::make_pair(p(0, 0), p(0, 1));
}