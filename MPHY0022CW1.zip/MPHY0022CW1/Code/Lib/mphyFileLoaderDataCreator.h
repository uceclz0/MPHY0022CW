#ifndef MPHY_FILE_LOADER_DATA_CREATOR_H_
#define MPHY_FILE_LOADER_DATA_CREATOR_H_

#include "mphyDataCreatorI.h"
#include "mphyBasicTypes.h"
#include <string>
class mphyFileLoaderDataCreator : public IDataCreator {
 private:
    std::string filename;
 public:
	mphy::LabelledData GetData();
	mphyFileLoaderDataCreator(std::string const &filename);
};
#endif

