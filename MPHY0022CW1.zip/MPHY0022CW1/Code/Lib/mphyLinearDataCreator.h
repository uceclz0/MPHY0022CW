#ifndef MPHY_LINEAR_DATA_CREATOR_H_
#define MPHY_LINEAR_DATA_CREATOR_H_
#include "./mphyDataCreatorI.h"
#include <random>
#include <chrono>
class mphyLinearDataCreator : public IDataCreator {
	std::default_random_engine generator{ static_cast<unsigned int> (std::chrono::system_clock::now().time_since_epoch().count())};
	std::uniform_real_distribution<double> dist{0.0, 1.0};
	double t_0, t_1, noise;
	int sample_size;
	std::pair<double, double> getOne(double x);
 public:
	mphy::LabelledData GetData();
	mphyLinearDataCreator(int, double, double);
};
#endif

