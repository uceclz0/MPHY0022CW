#ifndef MPHY_LINEAR_MODEL_SOLVER_STRATEGYI_H_
#define MPHY_LINEAR_MODEL_SOLVER_STRATEGYI_H_
#include <utility>
#include <vector>
#include "mphyBasicTypes.h"
class ISolverStrategy1 {
 public:
    virtual mphy::LinearSolution FitData(mphy::LabelledData) = 0;
};
#endif

