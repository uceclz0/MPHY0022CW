#include "./mphyLinearDataCreator.h"
#include <iostream>
std::pair<double, double> mphyLinearDataCreator::getOne(double x) {
	double noise = dist(generator) / 1e3;
	return std::make_pair(x, t_0 * x + t_1 + noise);
}

mphy::LabelledData mphyLinearDataCreator::GetData() {
	mphy::LabelledData	ret;
	for (int i = 0; i < sample_size; ++i) {
		double x = 2 * dist(generator);
		ret.push_back(getOne(x));
	}
	return ret;
}

mphyLinearDataCreator::mphyLinearDataCreator(int sample_size, double t_0, double t_1):
	sample_size(sample_size),
	t_0(t_0),
	t_1(t_1) {}
