#ifndef MPHY_GRADIENT_DESCENT_SOLVER_STRATEGY_H_
#define MPHY_GRADIENT_DESCENT_SOLVER_STRATEGY_H_
#include "mphyLinearModelSolverStrategyI.h"
#include <random>
#include <chrono>
class mphyGradientDescentSolverStrategy : public ISolverStrategy1 {
private:
  int iteration;
  double eta;
  std::default_random_engine generator{ static_cast<unsigned int> (std::chrono::system_clock::now().time_since_epoch().count())};
  std::uniform_real_distribution<double> dist{0.0, 1.0};
public:
  mphyGradientDescentSolverStrategy(int, double);
  mphy::LinearSolution FitData(mphy::LabelledData);
};
#endif




