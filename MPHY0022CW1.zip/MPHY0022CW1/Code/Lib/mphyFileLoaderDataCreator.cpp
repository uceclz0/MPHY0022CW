#include "mphyFileLoaderDataCreator.h"
#include <fstream>
#include <utility>
mphy::LabelledData mphyFileLoaderDataCreator::GetData() {
    mphy::LabelledData ret;
    std::ifstream ifs(filename);
    double x, y;
    while (ifs >> x >> y) {
        ret.push_back(std::make_pair(x, y));
    }
    ifs.close();
    return ret;
}

mphyFileLoaderDataCreator::mphyFileLoaderDataCreator(std::string const &filename):
    filename(filename) {}