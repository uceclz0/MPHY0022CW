#ifndef MPHYDATACREATORI_H_
#define MPHYDATACREATORI_H_
#include "mphyBasicTypes.h"
#include <vector>
class IDataCreator {
    public:
        virtual mphy::LabelledData GetData() = 0;
};
#endif

