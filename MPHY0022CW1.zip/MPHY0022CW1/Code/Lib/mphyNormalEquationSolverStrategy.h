#ifndef MPHY_NORMAL_EQUATION_SOLVER_STRATEGY_H_
#define MPHY_NORMAL_EQUATION_SOLVER_STRATEGY_H_
#include "mphyLinearModelSolverStrategyI.h"
class mphyNormalEquationSolverStrategy : public ISolverStrategy1 {
 public:
    mphy::LinearSolution FitData(mphy::LabelledData);
};
#endif

