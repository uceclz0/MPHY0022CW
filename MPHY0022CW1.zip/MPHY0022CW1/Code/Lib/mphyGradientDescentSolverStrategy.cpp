#include <Eigen/Dense>
#include "mphyGradientDescentSolverStrategy.h"

mphyGradientDescentSolverStrategy::
mphyGradientDescentSolverStrategy(int iteration, double eta):
    iteration(iteration),
    eta(eta)  {}

mphy::LinearSolution mphyGradientDescentSolverStrategy::FitData(mphy::LabelledData v) {
    Eigen::MatrixXd x(v.size(), 2);
    Eigen::MatrixXd y(v.size(), 1);
    Eigen::MatrixXd theta(1, 2);
    for (int i = 0; i < v.size(); ++i) {
        x(i, 0) = 1;
        x(i, 1) = v[i].first;
        y(i, 0) = v[i].second;
    }

    theta(0, 0) = dist(generator);
    theta(0, 1) = dist(generator);

    int m = v.size();
    auto t = x.transpose();

    for (int i = 0; i < iteration; ++i) {
        auto gradients = 2.0 / m * 
                         t * (x * theta - y);
        theta -= eta * gradients;
    }
    return std::make_pair(theta(0, 0), theta(0, 1));
}