#include <iostream>
#include <string>
#include <stdexcept>
#include "mphyFileLoaderDataCreator.h"
#include "mphyNormalEquationSolverStrategy.h"
#include "mphyGradientDescentSolverStrategy.h"
using namespace std;
void usage(const string & name) {
    cout << "usage " << name << " File [Solver]" << endl;
    cout << "       Solver = normal(default) | gradient" << endl;
    cout << "       normal: Solve Normal Equation" << endl;
    cout << "       gradient: Solve with Gradient Descent" << endl;
}

int main(int argc, char **argv) {
    try{
        if (argc != 2 && argc != 3) {
            cout << "Invalid number of arguments" << endl;
            usage(argv[0]);
            return 1;
        }
        int method = 0;
        string filename;

        if (argc == 2) {
            filename = argv[1];
        }

        if (argc == 3) {
            filename = argv[1];
            string m = argv[2];
            if (m == "normal") {
                method = 0;
            } else if (m == "gradient") {
                method = 1;
            } else {
                cout << "Unknown solver name" << endl;
                usage(argv[0]);
                return 1;
            }
        }

        mphyFileLoaderDataCreator fd(filename);
        auto vec = fd.GetData();
        if (vec.empty()) {
            throw runtime_error("Can't read any data or file not found");
        }

        mphy::LinearSolution fit;
        ISolverStrategy1 *solver;
        if (method == 0) {
            solver = new mphyNormalEquationSolverStrategy;
        } else {
            solver = new mphyGradientDescentSolverStrategy(10000, 0.2);
        }

        fit = solver->FitData(vec);
        delete solver;
        cout << "The result is:" << endl;
        cout << "theta_1: " << fit.first << endl;
        cout << "theta_0: " << fit.second << endl;
    } catch (const std::runtime_error &e) {
        cout << e.what() << endl;
        return 2;
    }
    return 0;
}